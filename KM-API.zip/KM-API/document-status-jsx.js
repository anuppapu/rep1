import React, { useState } from 'react';
import { FileText, Search, CheckCircle, XCircle, Clock } from 'lucide-react';
import './DocumentStatus.css';

const DocumentStatus = ({ documents }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredDocs = documents.filter(doc =>
    doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doc.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doc.ksId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="status-icon success" />;
      case 'processing':
        return <Clock className="status-icon processing" />;
      case 'failed':
        return <XCircle className="status-icon error" />;
      default:
        return <Clock className="status-icon" />;
    }
  };

  return (
    <div className="document-status-container">
      <div className="feature-header">
        <FileText className="feature-icon" />
        <h2>Document Status</h2>
      </div>

      <div className="search-bar">
        <Search size={20} />
        <input
          type="text"
          placeholder="Search by document name, ID, or KS ID..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="documents-grid">
        {filteredDocs.length > 0 ? (
          filteredDocs.map(doc => (
            <div key={doc.id} className="document-card">
              <div className="doc-header">
                <FileText size={24} />
                {getStatusIcon(doc.status)}
              </div>
              <h3>{doc.name}</h3>
              <div className="doc-details">
                <p><strong>Document ID:</strong> <span className="mono">{doc.id}</span></p>
                <p><strong>KS ID:</strong> <span className="mono">{doc.ksId}</span></p>
                <p><strong>Size:</strong> {(doc.size / 1024).toFixed(2)} KB</p>
                <p>
                  <strong>Status:</strong>{' '}
                  <span className={`status-badge ${doc.status}`}>{doc.status}</span>
                </p>
                <p><strong>Uploaded:</strong> {new Date(doc.uploadedAt).toLocaleString()}</p>
              </div>
            </div>
          ))
        ) : (
          <div className="empty-state">
            <FileText size={64} />
            <p>No documents found</p>
            <span>Upload documents to see them here</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default DocumentStatus;
