import React, { useState } from 'react';
import { Upload, FileText, Loader } from 'lucide-react';
import './Ingest.css';

const Ingest = ({ config, isConfigured, documents, setDocuments, ingestionHistory, setIngestionHistory, showNotification }) => {
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [uploadProgress, setUploadProgress] = useState({});
  const [loading, setLoading] = useState(false);

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files);
    setSelectedFiles(prev => [...prev, ...files]);
  };

  const removeFile = (index) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpload = async () => {
    if (!isConfigured()) {
      showNotification('Please configure API Key and KB ID first', 'error');
      return;
    }

    if (selectedFiles.length === 0) {
      showNotification('Please select files to upload', 'warning');
      return;
    }

    setLoading(true);
    const newDocs = [];

    for (const file of selectedFiles) {
      const docId = `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      setUploadProgress(prev => ({ ...prev, [file.name]: 0 }));

      // Simulate upload progress
      for (let i = 0; i <= 100; i += 20) {
        await new Promise(resolve => setTimeout(resolve, 200));
        setUploadProgress(prev => ({ ...prev, [file.name]: i }));
      }

      const newDoc = {
        id: docId,
        name: file.name,
        size: file.size,
        status: 'processing',
        uploadedAt: new Date().toISOString(),
        ksId: `ks_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      };

      newDocs.push(newDoc);
      setIngestionHistory(prev => [newDoc, ...prev]);
    }

    setDocuments(prev => [...prev, ...newDocs]);
    setSelectedFiles([]);
    setUploadProgress({});
    setLoading(false);
    showNotification(`Successfully uploaded ${newDocs.length} document(s)`, 'success');

    // Simulate status changes
    setTimeout(() => {
      setDocuments(prev => prev.map(doc => 
        newDocs.find(nd => nd.id === doc.id) ? { ...doc, status: 'completed' } : doc
      ));
    }, 3000);
  };

  return (
    <div className="ingest-container">
      <div className="feature-header">
        <Upload className="feature-icon" />
        <h2>Document Ingestion</h2>
      </div>
      
      <div className="upload-area">
        <input
          type="file"
          multiple
          onChange={handleFileSelect}
          id="file-input"
          className="file-input"
          accept=".pdf,.doc,.docx,.txt"
        />
        <label htmlFor="file-input" className="upload-label">
          <Upload size={48} />
          <p>Click to select files or drag and drop</p>
          <span>Supports PDF, DOCX, TXT, and more</span>
        </label>
      </div>

      {selectedFiles.length > 0 && (
        <div className="selected-files">
          <h3>Selected Files ({selectedFiles.length})</h3>
          {selectedFiles.map((file, idx) => (
            <div key={idx} className="file-item">
              <FileText size={20} />
              <div className="file-info">
                <span className="file-name">{file.name}</span>
                <span className="file-size">{(file.size / 1024).toFixed(2)} KB</span>
              </div>
              {uploadProgress[file.name] !== undefined && (
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: `${uploadProgress[file.name]}%` }}></div>
                </div>
              )}
              {!loading && (
                <button className="remove-btn" onClick={() => removeFile(idx)}>×</button>
              )}
            </div>
          ))}
          <button className="btn btn-primary" onClick={handleUpload} disabled={loading}>
            {loading ? <Loader className="spin" size={18} /> : <Upload size={18} />}
            {loading ? 'Uploading...' : 'Upload Documents'}
          </button>
        </div>
      )}
    </div>
  );
};

export default Ingest;
