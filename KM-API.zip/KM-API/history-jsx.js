import React from 'react';
import { History as HistoryIcon, FileText } from 'lucide-react';
import './History.css';

const History = ({ ingestionHistory }) => {
  const groupedHistory = ingestionHistory.reduce((acc, doc) => {
    if (!acc[doc.ksId]) {
      acc[doc.ksId] = [];
    }
    acc[doc.ksId].push(doc);
    return acc;
  }, {});

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="history-container">
      <div className="feature-header">
        <HistoryIcon className="feature-icon" />
        <h2>Ingestion History</h2>
      </div>

      <div className="history-timeline">
        {Object.keys(groupedHistory).length > 0 ? (
          Object.entries(groupedHistory).map(([ksId, docs], index) => (
            <div key={ksId} className="history-group" style={{ animationDelay: `${index * 0.1}s` }}>
              <div className="ks-header">
                <h3>KS ID: {ksId}</h3>
                <span className="doc-count">{docs.length} document(s)</span>
              </div>
              <div className="history-items">
                {docs.map((doc, docIndex) => (
                  <div 
                    key={doc.id} 
                    className="history-item"
                    style={{ animationDelay: `${(index * 0.1) + (docIndex * 0.05)}s` }}
                  >
                    <div className="timeline-dot"></div>
                    <div className="history-content">
                      <div className="history-title">
                        <FileText size={18} />
                        <strong>{doc.name}</strong>
                        <span className={`status-badge ${doc.status}`}>{doc.status}</span>
                      </div>
                      <div className="history-meta">
                        <p>Document ID: <span className="mono">{doc.id}</span></p>
                        <p>Size: {(doc.size / 1024).toFixed(2)} KB</p>
                      </div>
                      <p className="timestamp">
                        <HistoryIcon size={14} />
                        {formatDate(doc.uploadedAt)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))
        ) : (
          <div className="empty-state">
            <HistoryIcon size={64} />
            <p>No ingestion history available</p>
            <span>Upload documents to see the history</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default History;
