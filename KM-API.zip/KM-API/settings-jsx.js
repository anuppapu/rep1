import React, { useState } from 'react';
import { Settings as SettingsIcon } from 'lucide-react';
import './Settings.css';

const Settings = ({ config, setConfig, showNotification }) => {
  const [localConfig, setLocalConfig] = useState(config);

  const API_URLS = {
    dev: 'https://api-dev.example.com/kb',
    qa: 'https://api-qa.example.com/kb',
    prod: 'https://api-prod.example.com/kb'
  };

  const handleSave = () => {
    if (!localConfig.apiKey.trim()) {
      showNotification('Please enter an API Key', 'error');
      return;
    }
    if (!localConfig.kbId.trim()) {
      showNotification('Please enter a Knowledge Base ID', 'error');
      return;
    }
    setConfig(localConfig);
    showNotification('Configuration saved successfully', 'success');
  };

  return (
    <div className="settings-container">
      <div className="feature-header">
        <SettingsIcon className="feature-icon" />
        <h2>Configuration</h2>
      </div>

      <div className="settings-form">
        <div className="form-group">
          <label>Environment</label>
          <div className="env-selector">
            {['dev', 'qa', 'prod'].map(env => (
              <button
                key={env}
                className={`env-btn ${localConfig.environment === env ? 'active' : ''}`}
                onClick={() => setLocalConfig({ ...localConfig, environment: env })}
              >
                {env.toUpperCase()}
              </button>
            ))}
          </div>
          <span className="helper-text">API URL: {API_URLS[localConfig.environment]}</span>
        </div>

        <div className="form-group">
          <label>API Key *</label>
          <input
            type="password"
            placeholder="Enter your API key..."
            value={localConfig.apiKey}
            onChange={(e) => setLocalConfig({ ...localConfig, apiKey: e.target.value })}
          />
          <span className="helper-text">Required for authentication</span>
        </div>

        <div className="form-group">
          <label>Knowledge Base ID *</label>
          <input
            type="text"
            placeholder="Enter your KB ID..."
            value={localConfig.kbId}
            onChange={(e) => setLocalConfig({ ...localConfig, kbId: e.target.value })}
          />
          <span className="helper-text">Your unique knowledge base identifier</span>
        </div>

        <button className="btn btn-primary btn-large" onClick={handleSave}>
          Save Configuration
        </button>
      </div>
    </div>
  );
};

export default Settings;
