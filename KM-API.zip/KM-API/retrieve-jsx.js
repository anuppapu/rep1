import React, { useState } from 'react';
import { Search, FileText } from 'lucide-react';
import './Retrieve.css';

const Retrieve = ({ documents, showNotification }) => {
  const [ksId, setKsId] = useState('');
  const [retrievedDocs, setRetrievedDocs] = useState([]);
  const [searched, setSearched] = useState(false);

  const handleRetrieve = () => {
    if (!ksId.trim()) {
      showNotification('Please enter a KS ID', 'error');
      return;
    }

    const filtered = documents.filter(doc => doc.ksId === ksId.trim());
    setRetrievedDocs(filtered);
    setSearched(true);
    
    if (filtered.length === 0) {
      showNotification('No documents found for this KS ID', 'warning');
    } else {
      showNotification(`Found ${filtered.length} document(s)`, 'success');
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleRetrieve();
    }
  };

  return (
    <div className="retrieve-container">
      <div className="feature-header">
        <Search className="feature-icon" />
        <h2>Retrieve Documents</h2>
      </div>

      <div className="retrieve-section">
        <div className="input-group">
          <input
            type="text"
            placeholder="Enter KS ID to retrieve documents..."
            value={ksId}
            onChange={(e) => setKsId(e.target.value)}
            onKeyPress={handleKeyPress}
          />
          <button className="btn btn-primary" onClick={handleRetrieve}>
            <Search size={18} />
            Retrieve
          </button>
        </div>

        {searched && retrievedDocs.length > 0 && (
          <div className="retrieved-list">
            <div className="list-header">
              <h3>Retrieved Documents ({retrievedDocs.length})</h3>
              <span className="ks-badge">{ksId}</span>
            </div>
            {retrievedDocs.map(doc => (
              <div key={doc.id} className="retrieved-item">
                <FileText size={20} />
                <div className="retrieved-info">
                  <strong>{doc.name}</strong>
                  <span>Document ID: {doc.id}</span>
                  <span className="doc-meta">
                    Size: {(doc.size / 1024).toFixed(2)} KB • 
                    Status: <span className={`status-inline ${doc.status}`}>{doc.status}</span>
                  </span>
                </div>
                <span className={`status-badge ${doc.status}`}>{doc.status}</span>
              </div>
            ))}
          </div>
        )}

        {searched && retrievedDocs.length === 0 && (
          <div className="no-results">
            <Search size={64} />
            <p>No documents found</p>
            <span>Try searching with a different KS ID</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default Retrieve;
