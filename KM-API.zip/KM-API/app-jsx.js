import React, { useState } from 'react';
import { Settings as SettingsIcon, Upload, FileText, Search, History, MessageSquare, CheckCircle } from 'lucide-react';
import Settings from './components/Settings';
import Ingest from './components/Ingest';
import DocumentStatus from './components/DocumentStatus';
import Retrieve from './components/Retrieve';
import HistoryComponent from './components/History';
import ChatPanel from './components/ChatPanel';
import './App.css';

const App = () => {
  const [activeTab, setActiveTab] = useState('settings');
  const [config, setConfig] = useState({
    environment: 'dev',
    apiKey: '',
    kbId: ''
  });
  const [documents, setDocuments] = useState([]);
  const [ingestionHistory, setIngestionHistory] = useState([]);
  const [chatMessages, setChatMessages] = useState([]);
  const [notification, setNotification] = useState(null);

  const showNotification = (message, type = 'info') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  const isConfigured = () => config.apiKey && config.kbId;

  const tabs = [
    { id: 'settings', label: 'Settings', icon: SettingsIcon },
    { id: 'ingest', label: 'Ingest', icon: Upload },
    { id: 'status', label: 'Status', icon: FileText },
    { id: 'retrieve', label: 'Retrieve', icon: Search },
    { id: 'history', label: 'History', icon: History },
    { id: 'chat', label: 'Chat', icon: MessageSquare }
  ];

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'settings':
        return <Settings config={config} setConfig={setConfig} showNotification={showNotification} />;
      case 'ingest':
        return (
          <Ingest
            config={config}
            isConfigured={isConfigured}
            documents={documents}
            setDocuments={setDocuments}
            ingestionHistory={ingestionHistory}
            setIngestionHistory={setIngestionHistory}
            showNotification={showNotification}
          />
        );
      case 'status':
        return <DocumentStatus documents={documents} />;
      case 'retrieve':
        return <Retrieve documents={documents} showNotification={showNotification} />;
      case 'history':
        return <HistoryComponent ingestionHistory={ingestionHistory} />;
      case 'chat':
        return (
          <ChatPanel
            config={config}
            isConfigured={isConfigured}
            chatMessages={chatMessages}
            setChatMessages={setChatMessages}
            showNotification={showNotification}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="app-container">
      {notification && (
        <div className={`notification ${notification.type}`}>
          <CheckCircle size={20} />
          {notification.message}
        </div>
      )}

      <div className="header">
        <div className="header-content">
          <div className="header-title">
            <FileText size={36} />
            <h1>Knowledge Base Management System</h1>
          </div>
          <div className={`config-status ${isConfigured() ? 'configured' : ''}`}>
            {isConfigured() ? (
              <>
                <CheckCircle size={20} />
                <span>Configured</span>
              </>
            ) : (
              <>
                <SettingsIcon size={20} />
                <span>Setup Required</span>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="main-content">
        <div className="sidebar">
          <div className="nav-tabs">
            {tabs.map(tab => (
              <button
                key={tab.id}
                className={`nav-tab ${activeTab === tab.id ? 'active' : ''}`}
                onClick={() => setActiveTab(tab.id)}
              >
                <tab.icon size={20} />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="content-area">
          {renderActiveComponent()}
        </div>
      </div>
    </div>
  );
};

export default App;
