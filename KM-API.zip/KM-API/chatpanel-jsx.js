import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, Loader, Trash2 } from 'lucide-react';
import './ChatPanel.css';

const ChatPanel = ({ config, isConfigured, chatMessages, setChatMessages, showNotification }) => {
  const [chatInput, setChatInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages]);

  const handleSendMessage = async () => {
    if (!chatInput.trim()) return;
    
    if (!isConfigured()) {
      showNotification('Please configure API Key and KB ID first', 'error');
      return;
    }

    const userMessage = { 
      role: 'user', 
      content: chatInput, 
      timestamp: new Date() 
    };
    
    setChatMessages(prev => [...prev, userMessage]);
    setChatInput('');
    setLoading(true);

    // Simulate API call
    setTimeout(() => {
      const aiMessage = {
        role: 'assistant',
        content: `Based on the ingested documents, here's the information about "${chatInput}". This response is retrieved from your knowledge base using the configured API endpoint (${config.environment.toUpperCase()}).`,
        timestamp: new Date()
      };
      setChatMessages(prev => [...prev, aiMessage]);
      setLoading(false);
    }, 1500);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const clearChat = () => {
    setChatMessages([]);
    showNotification('Chat history cleared', 'info');
  };

  return (
    <div className="chat-panel-container">
      <div className="feature-header">
        <MessageSquare className="feature-icon" />
        <h2>Chat with Documents</h2>
        {chatMessages.length > 0 && (
          <button className="clear-btn" onClick={clearChat} title="Clear chat">
            <Trash2 size={18} />
          </button>
        )}
      </div>

      <div className="chat-messages">
        {chatMessages.length > 0 ? (
          <>
            {chatMessages.map((msg, idx) => (
              <div key={idx} className={`message ${msg.role}`}>
                <div className="message-avatar">
                  {msg.role === 'user' ? '👤' : '🤖'}
                </div>
                <div className="message-content">
                  <p>{msg.content}</p>
                  <span className="message-time">
                    {msg.timestamp.toLocaleTimeString()}
                  </span>
                </div>
              </div>
            ))}
            {loading && (
              <div className="message assistant">
                <div className="message-avatar">🤖</div>
                <div className="message-content loading">
                  <Loader className="spin" size={20} />
                  <span>Thinking...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </>
        ) : (
          <div className="empty-chat">
            <MessageSquare size={64} />
            <p>Start chatting with your documents</p>
            <span>Ask questions about the content you've uploaded</span>
            <div className="sample-questions">
              <h4>Try asking:</h4>
              <button 
                className="sample-q" 
                onClick={() => setChatInput('What are the main topics in the documents?')}
              >
                What are the main topics in the documents?
              </button>
              <button 
                className="sample-q" 
                onClick={() => setChatInput('Summarize the key findings')}
              >
                Summarize the key findings
              </button>
              <button 
                className="sample-q" 
                onClick={() => setChatInput('What insights can you provide?')}
              >
                What insights can you provide?
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="chat-input-container">
        <textarea
          placeholder="Ask a question about your documents..."
          value={chatInput}
          onChange={(e) => setChatInput(e.target.value)}
          onKeyPress={handleKeyPress}
          disabled={!isConfigured()}
          rows="1"
        />
        <button 
          className="btn btn-primary send-btn" 
          onClick={handleSendMessage}
          disabled={!chatInput.trim() || !isConfigured() || loading}
        >
          <Send size={18} />
        </button>
      </div>
    </div>
  );
};

export default ChatPanel;
